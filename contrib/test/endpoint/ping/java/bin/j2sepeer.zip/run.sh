#!/bin/sh
#
# $Id: run.sh,v 1.1 2002/02/12 23:45:17 lomax Exp $
#

exec java -classpath j2sepeer.jar -Dnet.jxta.tls.principal="relay" -Dnet.jxta.tls.password="testingnow" net.jxta.impl.peergroup.Boot





